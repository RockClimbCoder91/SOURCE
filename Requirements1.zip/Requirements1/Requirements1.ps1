Write-Host "Hello World!"

Get-Process

Get-ChildItem -Path "c:\"